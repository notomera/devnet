netbox_circuits
====================================

Constants
---------
.. autodata:: plugins.module_utils.netbox_circuits.NB_PROVIDERS
.. autodata:: plugins.module_utils.netbox_circuits.NB_CIRCUIT_TYPES
.. autodata:: plugins.module_utils.netbox_circuits.NB_CIRCUIT_TERMINATIONS
.. autodata:: plugins.module_utils.netbox_circuits.NB_CIRCUITS

Classes
-------
.. autoclass:: plugins.module_utils.netbox_circuits.NetboxCircuitsModule
