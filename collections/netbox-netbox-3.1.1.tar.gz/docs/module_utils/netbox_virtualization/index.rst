netbox_virtualization
====================================

Constants
---------
.. autodata:: plugins.module_utils.netbox_virtualization.NB_VIRTUAL_MACHINES
.. autodata:: plugins.module_utils.netbox_virtualization.NB_CLUSTERS
.. autodata:: plugins.module_utils.netbox_virtualization.NB_CLUSTER_GROUP
.. autodata:: plugins.module_utils.netbox_virtualization.NB_CLUSTER_TYPE
.. autodata:: plugins.module_utils.netbox_virtualization.NB_VM_INTERFACES

Classes
-------
.. autoclass:: plugins.module_utils.netbox_virtualization.NetboxVirtualizationModule
