==============================================
Contributing Updates to the Inventory Plugin
==============================================

.. toctree::
   :maxdepth: 4
